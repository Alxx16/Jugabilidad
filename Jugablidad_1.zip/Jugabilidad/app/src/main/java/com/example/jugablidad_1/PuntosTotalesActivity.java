package com.example.jugablidad_1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class PuntosTotalesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_puntos_totales);
    }
}